# 2022/04/24

rm a.out

gcc test_cost_fitness_1.c -fopenmp -lm

#gcc test_cost_open_omp.c -fopenmp

./a.out
