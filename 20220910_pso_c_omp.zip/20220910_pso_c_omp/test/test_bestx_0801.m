rmin = [-10,-10,-10];
rmax = [10,10,10];

best_s = [0.550014, 0.600034, 0.649910];
best_c =  rmin + 20*best_s;

best_c